<?php 

$_SESSION['name'] = 'OLMS';


?>