   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                  <b> &copy; <?php echo date('Y'); echo '  '.'OLMS';?></b> </a> 
                </div>

            </div>
        </div>
    </section>
    